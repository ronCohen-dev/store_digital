package com.example.serviceA.advice;

import com.example.serviceA.exception.InviteException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

@ControllerAdvice //@After throwing
@RestController
@Slf4j
public class EmployeeControllerAdvice {

    @ExceptionHandler(value = {InviteException.class})
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    public ErorDidails exceptionHandler(Exception e){
        return new ErorDidails("Your request failed because : " , e.getMessage());
    }


    public void logOperation(){
      log.info(".........");

    }
}
