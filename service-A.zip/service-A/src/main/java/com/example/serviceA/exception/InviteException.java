package com.example.serviceA.exception;

public class InviteException extends Exception{

    public InviteException(ErrMassage errMassage){
        super(errMassage.getDesc());
    }
}
