package com.example.serviceA.service;

import com.example.serviceA.exception.InviteException;
import com.example.serviceA.model.Invite;

import java.util.List;

public interface InviteService {

    Invite addInv(Invite invite) throws InviteException;
    Invite deleteInv (int id) throws InviteException;
    Invite updateInv (Invite invite) throws InviteException;
    Invite getInv(int id) throws InviteException;
    List<Invite> getAllInv() throws InviteException;
}
