package com.example.serviceA.service;

import com.example.serviceA.exception.ErrMassage;
import com.example.serviceA.exception.InviteException;
import com.example.serviceA.model.Invite;
import com.example.serviceA.repository.InviteRepositiry;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
@Slf4j
public class InviteServiceImpl implements InviteService{

    private final InviteRepositiry inviteRepositiry;

    @Override
    public Invite addInv(Invite invite) throws InviteException {
        if(inviteRepositiry.existsById(invite.getId())) throw new InviteException(ErrMassage.ID_ALREDY_EXISTS);
        inviteRepositiry.save(invite);
        log.info("This invite is added : " + invite);
        return invite;
    }

    @Override
    public Invite deleteInv(int id) throws InviteException {
        if(!inviteRepositiry.existsById(id))throw new InviteException(ErrMassage.ID_NOT_FOUND);
        Invite inviteForResponse = getInv(id);
        inviteRepositiry.deleteById(id);
        log.info("This invite is remove by this id : " + id);
        return inviteForResponse;
    }

    @Override
    public Invite updateInv(Invite invite) throws InviteException {
        if (!inviteRepositiry.existsById(invite.getId())) throw new InviteException(ErrMassage.ID_NOT_FOUND);
        inviteRepositiry.saveAndFlush(invite);
        log.debug("This the invite i just update : " + invite.getId());
        return invite;
    }

    @Override
    public Invite getInv(int id) throws InviteException {
        log.debug("This the invite i wont to get : " + id);
        return inviteRepositiry.findById(id).orElseThrow(()-> new InviteException(ErrMassage.ID_NOT_FOUND));
    }

    @Override
    public List<Invite> getAllInv() throws InviteException {
        return inviteRepositiry.findAll();
    }
}
