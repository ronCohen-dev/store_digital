package com.example.serviceA.controller;

import com.example.serviceA.exception.InviteException;
import com.example.serviceA.model.Invite;
import com.example.serviceA.service.InviteService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/invites")
@RequiredArgsConstructor
public class InviteResorce {

private final InviteService inviteService;


@PostMapping
@ResponseStatus(HttpStatus.CREATED)
    public Invite addInvates (@RequestBody Invite invite) throws InviteException{
   return inviteService.addInv(invite);
}
    @PutMapping
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public Invite updateInvite (@RequestBody Invite invite) throws InviteException{
    return inviteService.updateInv(invite);
    }

    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public Invite removeInvite (@PathVariable int id) throws InviteException{
        return inviteService.deleteInv(id);
    }

    @GetMapping("/{id}")
    public Invite getInvites(@PathVariable int id) throws InviteException{
    return inviteService.getInv(id);
    }

    @GetMapping
    public List<Invite> getAllInvitesInSystem() throws InviteException {
        return inviteService.getAllInv();
    }
}
