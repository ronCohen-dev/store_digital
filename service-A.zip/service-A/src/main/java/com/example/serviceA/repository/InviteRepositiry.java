package com.example.serviceA.repository;

import com.example.serviceA.model.Invite;
import org.springframework.data.jpa.repository.JpaRepository;

public interface InviteRepositiry extends JpaRepository<Invite, Integer> {
}
