package com.example.serviceB.models;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import java.time.LocalDate;


@Data
@AllArgsConstructor
@NoArgsConstructor
public class Invite {

    private Integer id;
    private String descption;
    private boolean isDone;
    private LocalDate dateOfTheInvite;
    private String areaOfInvite;

}

