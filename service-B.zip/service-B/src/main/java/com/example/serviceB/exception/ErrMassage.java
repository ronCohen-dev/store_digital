package com.example.serviceB.exception;

public enum ErrMassage {

    ID_ALREDY_EXISTS ("This id found !"),
    ID_NOT_FOUND  ("This id not found !");

    private String desc;

    ErrMassage(String desc) {
        this.desc= desc;

    }
    public String getDesc() {
        return desc;
    }
}
