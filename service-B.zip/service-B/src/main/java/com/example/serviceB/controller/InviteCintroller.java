package com.example.serviceB.controller;

import com.example.serviceB.exception.InviteException;
import com.example.serviceB.models.Invite;
import com.example.serviceB.models.ListOfInvites;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.client.RestTemplate;

@RestController
@RequestMapping("/invites")
@RequiredArgsConstructor
@Slf4j
public class InviteCintroller {

   private final RestTemplate restTemplate;

   @PostMapping
   public Invite AddInvite (@RequestBody Invite invite) throws InviteException {
       return restTemplate.postForObject("http://service-a/invites" ,invite, Invite.class);

   }

   @PutMapping
    public void updateInvite (@RequestBody Invite invite) throws InviteException{
        restTemplate.put("http://service-a/invites",invite,Invite.class);
        log.info("This invite you set to microservice A : " + invite);
   }

   @DeleteMapping("/{id}")
  public void removeInvite(@PathVariable int id) throws InviteException{
        restTemplate.delete("http://service-a/invites/" + id , Invite.class);
        log.info("This object is remove from microservice A with this id : " + id);
   }

   @GetMapping("{id}")
    public Invite getSpeceficInvite(@PathVariable int id) throws InviteException {
      return restTemplate.getForObject("http://service-a/invites/" + id , Invite.class);
   }

   // trows exception this method below
   @GetMapping
    public ListOfInvites getAllInvites() throws InviteException{
      return  restTemplate.getForObject("http://service-a/invites", ListOfInvites.class);
   }
}
